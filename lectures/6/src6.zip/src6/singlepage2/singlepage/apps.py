from django.apps import AppConfig


class SinglepageConfig(AppConfig):
    name = 'singlepage'
